import React from 'react';

const YourComponent = () => {
  const fetchIds = async () => {
    try {
      const response = await fetch('http://localhost:5000/getIds'); // Replace with your server URL
      if (!response.ok) {
        throw new Error('Network response was not ok.');
      }
      const data = await response.json();
      console.log(data); // This will print the fetched IDs to the console
    } catch (error) {
      console.error('There was a problem fetching the data:', error);
    }
  };

  return (
    <div>
      {/* Your component JSX */}
      <button onClick={fetchIds}>Fetch IDs</button>
    </div>
  );
};

export default YourComponent;

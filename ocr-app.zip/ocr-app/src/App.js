import React from 'react';
import './App.css';
import ImageUploader from './ImageUploader';
import YourComponent from './YourComponent';


function App() {
  return (
    <div className="App">
        
         <ImageUploader />
         <YourComponent/>         
    </div>
  );
}

export default App;
